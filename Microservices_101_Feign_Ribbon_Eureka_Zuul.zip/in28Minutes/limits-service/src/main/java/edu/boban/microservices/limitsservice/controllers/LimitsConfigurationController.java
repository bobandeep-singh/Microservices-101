package edu.boban.microservices.limitsservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.boban.microservices.limitsservice.beans.LimitConfigurations;
import edu.boban.microservices.limitsservice.configs.Configurations;

@RestController
public class LimitsConfigurationController {
	
	@Autowired
	private Configurations configurations;
	
	@GetMapping("/limits")
	public LimitConfigurations retreveLimitsFromConfigurations() {
		return new LimitConfigurations(configurations.getMaximum(), configurations.getMinimum());
	}
}
