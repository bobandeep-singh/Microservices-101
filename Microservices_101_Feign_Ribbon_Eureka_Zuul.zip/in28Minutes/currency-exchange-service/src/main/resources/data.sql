Insert into Exchange_Value (id, currency_from, currency_to, coversion_multiple, port)
values (1001, 'USD', 'INR', 75, 0);
Insert into Exchange_Value (id, currency_from, currency_to, coversion_multiple, port)
values (1002, 'CAD', 'INR', 52, 0);
Insert into Exchange_Value (id, currency_from, currency_to, coversion_multiple, port)
values (1003, 'AUS', 'INR', 50, 0);