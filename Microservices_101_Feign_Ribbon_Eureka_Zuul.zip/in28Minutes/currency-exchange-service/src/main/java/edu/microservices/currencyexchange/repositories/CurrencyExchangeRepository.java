package edu.microservices.currencyexchange.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.microservices.currencyexchange.beans.ExchangeValue;

public interface CurrencyExchangeRepository extends JpaRepository<ExchangeValue, Long> {

	public ExchangeValue findByFromAndTo(String from, String to);
}
