package com.microservices.currencyconversion.beans;

import java.math.BigDecimal;

public class ExchangeValue {

	private Long id;
	private String from;
	private String to;
	private BigDecimal coversionMultiple;
	private int port;

	public ExchangeValue() {
		super();
	}
	public ExchangeValue(Long id, String from, String to, BigDecimal coversionMultiple) {
		super();
		this.id = id;
		this.from = from;
		this.to = to;
		this.coversionMultiple = coversionMultiple;
	}
	public Long getId() {
		return id;
	}
	public String getFrom() {
		return from;
	}
	public String getTo() {
		return to;
	}
	public BigDecimal getCoversionMultiple() {
		return coversionMultiple;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public void setCoversionMultiple(BigDecimal coversionMultiple) {
		this.coversionMultiple = coversionMultiple;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
}
